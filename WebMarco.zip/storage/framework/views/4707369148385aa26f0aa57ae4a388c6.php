
<?php /**PATH C:\xampp\htdocs\ProjetCh\resources\views/layouts/app.blade.php ENDPATH**/ ?>