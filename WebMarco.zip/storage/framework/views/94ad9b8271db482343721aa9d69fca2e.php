<?php $__env->startSection('content'); ?>
<form action="<?php echo e(url('devis')); ?>" method="GET">
    <div class="input-group mb-3">
        <input type="text" class="form-control" placeholder="Search..." name="search" value="<?php echo e(old('search')); ?>">
        <button class="btn btn-outline-secondary" type="submit">Search</button>
    </div>
</form>
    <div class="col-lg-12 grid-margin stretch-card">
        <div class="card">
            <div class="card-body">
                <div class="row">
                    <div class="col-8">
                        <h4 class="card-title">Devis</h4>
                    </div>

                    <div class="col-4 d-flex justify-content-end ">
                        <a href="<?php echo e(url('devis/create')); ?>" class="btn btn-primary">
                            Nouveau Devis
                        </a>

                    </div>
                </div>
                </p>
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th> Id </th>
                            <th> Date </th>
                            <th> Objet </th>
                            <th> Nom Société </th>
                            <th> ICE </th>
                            <th> Client </th>
                            <th> Action </th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $devis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $devis): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($devis->id); ?></td>
                                <td><?php echo e($devis->date); ?></td>
                                <td><?php echo e($devis->objet); ?></td>
                                <td><?php echo e($devis->nom_societe); ?></td>
                                <td><?php echo e($devis->ice); ?></td>
                                <td><?php echo e($devis->client->nom); ?><br><?php echo e($devis->client->prenom); ?></td>
                                <td>
                                    <div class="dropdown">
                                        <a class="btn" href="#" role="button" data-bs-toggle="dropdown"
                                            aria-expanded="false">
                                            <i class="bi bi-three-dots-vertical"></i>
                                        </a>
                                        <ul class="dropdown-menu">
                                            <li><a class="dropdown-item"
                                                    href="<?php echo e(url('devis/' . $devis->id . '/edit')); ?>"><i
                                                        class="bi bi-pencil-square"></i> Modifier</a></li>
                                            <li><a class="dropdown-item" href="<?php echo e(url('devis/' . $devis->id)); ?>"><i
                                                        class="bi bi-info-circle"></i> Détails</a></li>

                                            <form action="<?php echo e(url('devis/' . $devis->id)); ?>" method="POST">
                                                <?php echo method_field('DELETE'); ?>
                                                <?php echo csrf_field(); ?>
                                                <button type="submit" class="dropdown-item"><i
                                                        class="bi bi-trash-fill"></i>Supprimer</button>
                                            </form>
                                            </li>
                                        </ul>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="9">il n'ya pas de devis</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

        <?php if($devisp->hasPages()): ?>
        <div class="pagination-summary">
            <p>Showing <?php echo e($devisp->firstItem()); ?> to <?php echo e($devisp->lastItem()); ?> of <?php echo e($devisp->total()); ?> records</p>
        </div>
        <nav>
            <ul class="pagination">
                
                <?php if($devisp->onFirstPage()): ?>
                    <li class="page-item disabled" aria-disabled="true" aria-label="<?php echo app('translator')->get('pagination.previous'); ?>">
                        <span class="page-link" aria-hidden="true">&lsaquo;</span>
                    </li>
                <?php else: ?>
                    <li class="page-item">
                        <a class="page-link" href="<?php echo e($devisp->previousPageUrl()); ?>" rel="prev"
                            aria-label="<?php echo app('translator')->get('pagination.previous'); ?>">&lsaquo;</a>
                    </li>
                <?php endif; ?>

                
                <?php $__currentLoopData = $devisp; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $devis): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="page-item <?php echo e($devisp->currentPage() === $loop->iteration ? 'active' : ''); ?>">
                        <a class="page-link"
                            href="<?php echo e(url()->current()); ?>?page=<?php echo e($loop->iteration); ?>"><?php echo e($loop->iteration); ?></a>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                
                <?php if($devisp->hasMorePages()): ?>
                    <li class="page-item">
                        <a class="page-link" href="<?php echo e($devisp->nextPageUrl()); ?>" rel="next"
                            aria-label="<?php echo app('translator')->get('pagination.next'); ?>">&rsaquo;</a>
                    </li>
                <?php else: ?>
                    <li class="page-item disabled" aria-disabled="true" aria-label="<?php echo app('translator')->get('pagination.next'); ?>">
                        <span class="page-link" aria-hidden="true">&rsaquo;</span>
                    </li>
                <?php endif; ?>
            </ul>
        </nav>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\WebMarco\resources\views/devis/index.blade.php ENDPATH**/ ?>