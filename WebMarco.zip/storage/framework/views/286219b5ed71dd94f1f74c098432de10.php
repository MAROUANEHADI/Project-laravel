<?php $__env->startSection('content'); ?>



<div class="col-12">
    <div class="card">
      <div class="card-body">
        <h4 class="card-title">Modifie Facture</h4>
        <form action="<?php echo e(url('facture/' . $facture->id)); ?>" enctype="multipart/form-data" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
          <div class="row">
            <div class="col-md-6">
              <div class="form-group row">
                <label class="col-sm-3 col-form-label">Nom Société</label>
                <div class="col-sm-9">
                  <input type="text" class="form-control"  name="nom_societe" value="<?php echo e($facture->nom_societe); ?>" required/>
                </div>
              </div>
            </div>
            <div class="col-md-6">
              <div class="form-group row">
                <label class="col-sm-3 col-form-label">Date</label>
                <div class="col-sm-9">
                  <input type="date" class="form-control" name="date" value="<?php echo e($facture->date); ?>" required/>
                </div>
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col-md-6">
              <div class="form-group row">
                <label class="col-sm-3 col-form-label">Objet</label>
                <div class="col-sm-9">
                  <input type="text" class="form-control" name="objet" value="<?php echo e($facture->objet); ?>" required/>
                </div>
              </div>
            </div>
            <div class="col-md-6">
                <div class="form-group row">
                  <label class="col-sm-3 col-form-label">ICE</label>
                  <div class="col-sm-9">
                    <input type="text" class="form-control" name="ice" value="<?php echo e($facture->ice); ?>" required/>
                  </div>
                </div>
              </div>
          </div>
          <div class="row">
            <div class="col-md-6">
              <div class="form-group row">
                <label class="col-sm-3 col-form-label">Devis</label>
                <div class="col-sm-9">
                    <select name="devis_id" id="devis_id" class="form-select">
                        <?php $__currentLoopData = $devis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $devis): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($devis->id); ?>"
                                <?php if($devis->id==$facture->devis_id){echo('selected="selected"');} ?>>
                                <?php echo e($devis->objet); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
              </div>
            </div>
          </div>
          <a href="/facture" class="btn btn-light">Fermer</a>
          <button type="submit" class="btn btn-gradient-primary me-2">Sauvegarder</button>
        </form>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\WebMarco\resources\views/facture/edit.blade.php ENDPATH**/ ?>