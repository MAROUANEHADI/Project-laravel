<?php $__env->startSection('content'); ?>
    <div class="col-12">
        <div class="card">
            <div class="card-body">
                <div class="row">
                    <div class="col-4">
                        <div class="form-group row">
                            <h3>Description</h3>
                            <div class="col-sm-9">
                                <p><?php echo e($service->description); ?></p>
                            </div>
                        </div>
                    </div>
                    <div class="col-4">
                        <div class="form-group row">
                            <h3>Prix ht</h3>
                            <div class="col-sm-9">
                                <p class="text-danger"><?php echo e($service->prix_ht); ?></p>
                            </div>
                        </div>
                    </div>

                    <div class="col-4">
                        <div class="form-group row">
                            <h3>Tva</h3>
                            <div class="col-sm-9">
                                <p><?php echo e($service->tva); ?></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <a href="/service" class="btn btn-light mt-2">Fermer</a>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\WebMarco\resources\views/service/show.blade.php ENDPATH**/ ?>