<?php $__env->startSection('content'); ?>



<div class="col-12">
    <div class="card">
      <div class="card-body">
        <h4 class="card-title">Modifie Service</h4>
        <form action="<?php echo e(url('service/' . $service->id)); ?>" enctype="multipart/form-data" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
          <div class="row">
            <div class="col-md-6">
              <div class="form-group row">
                <label class="col-sm-3 col-form-label">Description</label>
                <div class="col-sm-9">
                  <input type="text" class="form-control"  name="description" value="<?php echo e($service->description); ?>" required/>
                </div>
              </div>
            </div>
            <div class="col-md-6">
              <div class="form-group row">
                <label class="col-sm-3 col-form-label">Prix ht</label>
                <div class="col-sm-9">
                  <input type="text" class="form-control" name="prix_ht" value="<?php echo e($service->prix_ht); ?>" required/>
                </div>
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col-md-6">
              <div class="form-group row">
                <label class="col-sm-3 col-form-label">Tva</label>
                <div class="col-sm-9">
                  <input type="text" class="form-control" name="tva" value="<?php echo e($service->tva); ?>" required/>
                </div>
              </div>
            </div>
          </div>

          <a href="/service" class="btn btn-light">Fermer</a>
          <button type="submit" class="btn btn-gradient-primary me-2">Sauvegarder</button>
        </form>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ProjetCh\resources\views/service/edit.blade.php ENDPATH**/ ?>