
<?php /**PATH C:\xampp\htdocs\ProjetCh\resources\views/dashboard1.blade.php ENDPATH**/ ?>