<?php $__env->startSection('content'); ?>
<form action="<?php echo e(url('service')); ?>" method="GET">
    <div class="input-group mb-3">
        <input type="text" class="form-control" placeholder="Search..." name="search" value="<?php echo e(old('search')); ?>">
        <button class="btn btn-outline-secondary" type="submit">Search</button>
    </div>
</form>
    <div class="col-lg-12 grid-margin stretch-card">
        <div class="card">
            <div class="card-body">
                <div class="row">
                    <div class="col-8">
                        <h4 class="card-title">Sevice</h4>
                    </div>

                    <div class="col-4 d-flex justify-content-end ">
                        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addClient">
                            Nouveau Sevice
                        </button>
                        <!-- Modal Ajoute Sevice -->
                        <div class="modal fade" id="addClient" tabindex="-1" aria-labelledby="addClientLabel"
                            aria-hidden="true">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <form action="<?php echo e(url('service')); ?>" enctype="multipart/form-data" method="POST">
                                        <?php echo csrf_field(); ?>

                                        <div class="modal-header">
                                            <h1 class="modal-title fs-5" id="addClientLabel">Nouveau Sevice</h1>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                aria-label="Close"></button>
                                        </div>
                                        <div class="modal-body">
                                            <div class="input-group input-group-sm mb-3">
                                                <span class="input-group-text" id="inputGroup-sizing-sm">Description</span>
                                                <input type="text" name="description" class="form-control" required>
                                            </div>
                                            <div class="input-group input-group-sm mb-3">
                                                <span class="input-group-text" id="inputGroup-sizing-sm">Prix ht</span>
                                                <input type="text" name="prix_ht" class="form-control" required>
                                            </div>
                                            <div class="input-group input-group-sm mb-3">
                                                <span class="input-group-text" id="inputGroup-sizing-sm">Tva</span>
                                                <input type="text" name="tva" class="form-control" required>
                                            </div>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary"
                                                data-bs-dismiss="modal">Fermer</button>
                                            <button type="submit" class="btn btn-primary">Sauvegarder</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                </p>
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th> Id </th>
                            <th> Description </th>
                            <th> Prix ht </th>
                            <th> Tva </th>
                            <th> Action </th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($service->id); ?></td>
                                <td><?php echo e($service->description); ?></td>
                                <td class="text-danger"><?php echo e($service->prix_ht); ?> DH</td>
                                <td><?php echo e($service->tva); ?> %</td>
                                <td>
                                    <div class="dropdown">
                                        <a class="btn" href="#" role="button" data-bs-toggle="dropdown"
                                            aria-expanded="false">
                                            <i class="bi bi-three-dots-vertical"></i>
                                        </a>
                                        <ul class="dropdown-menu">
                                            <li><a class="dropdown-item"
                                                    href="<?php echo e(url('service/' . $service->id . '/edit')); ?>"><i
                                                        class="bi bi-pencil-square"></i> Modifier</a></li>
                                            <li><a class="dropdown-item" href="<?php echo e(url('service/' . $service->id)); ?>"><i
                                                        class="bi bi-info-circle"></i> Détails</a></li>

                                            <form action="<?php echo e(url('service/' . $service->id)); ?>" method="POST">
                                                <?php echo method_field('DELETE'); ?>
                                                <?php echo csrf_field(); ?>
                                                <button type="submit" class="dropdown-item"><i
                                                        class="bi bi-trash-fill"></i>Supprimer</button>
                                            </form>
                                            </li>
                                        </ul>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="9">il n'ya pas de service</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <?php if($services->hasPages()): ?>
        <div class="pagination-summary">
            <p>Showing <?php echo e($services->firstItem()); ?> to <?php echo e($services->lastItem()); ?> of <?php echo e($services->total()); ?> records</p>
        </div>
        <nav>
            <ul class="pagination">
                
                <?php if($services->onFirstPage()): ?>
                    <li class="page-item disabled" aria-disabled="true" aria-label="<?php echo app('translator')->get('pagination.previous'); ?>">
                        <span class="page-link" aria-hidden="true">&lsaquo;</span>
                    </li>
                <?php else: ?>
                    <li class="page-item">
                        <a class="page-link" href="<?php echo e($services->previousPageUrl()); ?>" rel="prev"
                            aria-label="<?php echo app('translator')->get('pagination.previous'); ?>">&lsaquo;</a>
                    </li>
                <?php endif; ?>

                
                <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="page-item <?php echo e($services->currentPage() === $loop->iteration ? 'active' : ''); ?>">
                        <a class="page-link"
                            href="<?php echo e(url()->current()); ?>?page=<?php echo e($loop->iteration); ?>"><?php echo e($loop->iteration); ?></a>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                
                <?php if($services->hasMorePages()): ?>
                    <li class="page-item">
                        <a class="page-link" href="<?php echo e($services->nextPageUrl()); ?>" rel="next"
                            aria-label="<?php echo app('translator')->get('pagination.next'); ?>">&rsaquo;</a>
                    </li>
                <?php else: ?>
                    <li class="page-item disabled" aria-disabled="true" aria-label="<?php echo app('translator')->get('pagination.next'); ?>">
                        <span class="page-link" aria-hidden="true">&rsaquo;</span>
                    </li>
                <?php endif; ?>
            </ul>
        </nav>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\h\WebMarco\resources\views/service/index.blade.php ENDPATH**/ ?>