<?php $__env->startSection('content'); ?>
    <div class="col-12">
        <div class="card">
            <div class="card-body">
                <div class="row">
                    <div class="col-4">
                        <div class="form-group row">
                            <h3>Nom Société</h3>
                            <div class="col-sm-9">
                                <p><?php echo e($client->nom_societe); ?></p>
                            </div>
                        </div>
                    </div>
                    <div class="col-4">
                        <div class="form-group row">
                            <h3>Prenom</h3>
                            <div class="col-sm-9">
                                <p><?php echo e($client->prenom); ?></p>
                            </div>
                        </div>
                    </div>

                    <div class="col-4">
                        <div class="form-group row">
                            <h3>Nom</h3>
                            <div class="col-sm-9">
                                <p><?php echo e($client->nom); ?></p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-4">
                        <div class="form-group row">
                            <h3>Telephone</h3>
                            <div class="col-sm-9">
                                <p><?php echo e($client->telephone); ?></p>
                            </div>
                        </div>
                    </div>
                    <div class="col-4">
                        <div class="form-group row">
                            <h3>ICE</h3>
                            <div class="col-sm-9">
                                <p><?php echo e($client->ice); ?></p>
                            </div>
                        </div>
                    </div>

                    <div class="col-4">
                        <div class="form-group row">
                            <h3>Adresse</h3>
                            <div class="col-sm-9">
                                <p><?php echo e($client->adresse); ?></p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-4">
                        <div class="form-group row">
                            <h3>Nombre Devis</h3>
                            <div class="col-sm-9">
                                <p><?php echo e($client->scoop_Nb_devis()); ?></p>
                            </div>
                        </div>
                    </div>
                    
                </div>
            </div>
        </div>
    </div>
    <a href="/client" class="btn btn-light mt-2">Fermer</a>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ProjetCh\resources\views/client/show.blade.php ENDPATH**/ ?>