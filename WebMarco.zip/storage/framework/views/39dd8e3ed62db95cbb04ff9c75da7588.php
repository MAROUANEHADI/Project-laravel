<?php $__env->startSection('content'); ?>



<div class="col-12">
    <div class="card">
      <div class="card-body">
        <h4 class="card-title">Modifie Devis</h4>
        <form action="<?php echo e(url('devis/' . $devis->id)); ?>" enctype="multipart/form-data" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
          <div class="row">
            <div class="col-md-6">
              <div class="form-group row">
                <label class="col-sm-3 col-form-label">Nom Société</label>
                <div class="col-sm-9">
                  <input type="text" class="form-control"  name="nom_societe" value="<?php echo e($devis->nom_societe); ?>" required/>
                </div>
              </div>
            </div>
            <div class="col-md-6">
              <div class="form-group row">
                <label class="col-sm-3 col-form-label">Date</label>
                <div class="col-sm-9">
                  <input type="date" class="form-control" name="date" value="<?php echo e($devis->date); ?>" required/>
                </div>
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col-md-6">
              <div class="form-group row">
                <label class="col-sm-3 col-form-label">Objet</label>
                <div class="col-sm-9">
                  <input type="text" class="form-control" name="objet" value="<?php echo e($devis->objet); ?>" required/>
                </div>
              </div>
            </div>
            <div class="col-md-6">
                <div class="form-group row">
                  <label class="col-sm-3 col-form-label">ICE</label>
                  <div class="col-sm-9">
                    <input type="text" class="form-control" name="ice" value="<?php echo e($devis->ice); ?>" required/>
                  </div>
                </div>
              </div>
          </div>
          <div class="row">
            <div class="col-md-6">
              <div class="form-group row">
                <label class="col-sm-3 col-form-label">Client</label>
                <div class="col-sm-9">
                    <select name="client_id" id="client_id" class="form-select">
                        <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($client->id); ?>"
                                <?php if($client->id==$devis->client_id){echo('selected="selected"');} ?>>
                                <?php echo e($client->nom); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
              </div>
            </div>
          </div>
          <a href="/devis" class="btn btn-light">Fermer</a>
          <button type="submit" class="btn btn-gradient-primary me-2">Sauvegarder</button>
        </form>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\WebMarco\resources\views/devis/edit.blade.php ENDPATH**/ ?>