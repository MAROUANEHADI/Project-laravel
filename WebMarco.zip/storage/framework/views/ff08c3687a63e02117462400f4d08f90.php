<?php $__env->startSection('content'); ?>
<div class="col-lg-10 grid-margin stretch-card">
    <div class="card">
      <div class="card-body">
        <h4 class="card-title">Detail Devis N°<?php echo e($devis->id); ?></h4>
        <p class="card-description">  <code>List Services</code>
        </p>
        <table class="table table-hover">
          <thead>
            <tr>
              <th>Service</th>
              <th>Quantité</th>
              <th>Prix</th>
              <th>Tva</th>
            </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $devis->detail_devis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail_devis): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td><?php echo e($detail_devis->service->description); ?></td>
              <td><?php echo e($detail_devis->quantite); ?></td>
              <td class="text-danger"> <?php echo e($detail_devis->prix_ht); ?> </td>
              <td><label class="badge badge-danger"><?php echo e($detail_devis->tva); ?></label></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ProjetCh\resources\views/devis/show.blade.php ENDPATH**/ ?>