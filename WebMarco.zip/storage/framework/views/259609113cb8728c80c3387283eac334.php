<?php $__env->startSection('content'); ?>
    <div class="col-12">
        <div class="card">
            <div class="card-body">
                <div class="row">
                    <div class="col-4">
                        <div class="form-group row">
                            <h3>Nom Société</h3>
                            <div class="col-sm-9">
                                <p><?php echo e($facture->nom_societe); ?></p>
                            </div>
                        </div>
                    </div>
                    <div class="col-4">
                        <div class="form-group row">
                            <h3>Date</h3>
                            <div class="col-sm-9">
                                <p><?php echo e($facture->date); ?></p>
                            </div>
                        </div>
                    </div>

                    <div class="col-4">
                        <div class="form-group row">
                            <h3>Obejt</h3>
                            <div class="col-sm-9">
                                <p><?php echo e($facture->objet); ?></p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-4">
                        <div class="form-group row">
                            <h3>Devis</h3>
                            <div class="col-sm-9">
                                <p><?php echo e($facture->devis->objet); ?></p>
                            </div>
                        </div>
                    </div>
                    <div class="col-4">
                        <div class="form-group row">
                            <h3>ICE</h3>
                            <div class="col-sm-9">
                                <p><?php echo e($facture->ice); ?></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <a href="/facture" class="btn btn-light mt-2">Fermer</a>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\WebMarco\resources\views/facture/show.blade.php ENDPATH**/ ?>