
<?php /**PATH C:\xampp\htdocs\ProjetCh\resources\views/layouts/navigation.blade.php ENDPATH**/ ?>